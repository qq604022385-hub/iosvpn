"""Compile each shipped SCVPN implementation and fault-inject real UDP paths."""
from pathlib import Path
import os,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
PREFIX=ROOT/'windows/build-deps/toolchain/mingw64'
OUT=ROOT/'logs/wifi-client-1.4.8';OUT.mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['PATH']=str(PREFIX/'bin')+os.pathsep+env.get('PATH','')
def run(args,timeout=120):
    p=subprocess.run(list(map(str,args)),cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=timeout)
    print(p.stdout,end='');print(p.stderr,end='')
    if p.returncode:raise SystemExit(p.returncode)
    return p.stdout+p.stderr
run([PREFIX/'bin/gcc.exe','--version'])
for name,source in [('windows','hillstone/native/scvpn.c'),('android','android-port/engine/src/frontends/android/app/src/main/jni/hillstone/scvpn.c'),('ios','ios/Native/scvpn.c')]:
    exe=OUT/(name+'-wifi-tests.exe')
    args=[PREFIX/'bin/gcc.exe','-std=gnu11','-O2','-Wall','-Wextra','-Werror',
          '-Wno-unknown-pragmas','-B'+str(PREFIX.relative_to(ROOT)/'lib')+'/',
          '-I'+str(PREFIX.relative_to(ROOT)/'include'),'-I.',
          '-DHS_ENGINE_SOURCE="'+source+'"','scripts/native/wifi_udp_test.c',
          '-L'+str(PREFIX.relative_to(ROOT)/'lib'),'-lssl','-lcrypto','-lws2_32','-lcrypt32','-lbcrypt',
          '-o',exe.relative_to(ROOT)]
    for directory in sorted((PREFIX/'lib/gcc').glob('*/*')):args.append('-B'+directory.relative_to(ROOT).as_posix()+'/')
    log=run(args)+run([exe],20)
    assert log.count('PASS:')==5
    (OUT/(name+'-udp-tests.log')).write_text(log,encoding='utf-8')
print('PASS: 15 actual loopback ESP recovery checks across three engine sources')
