"""Host behavioral checks against production C functions, not a second queue implementation."""
from pathlib import Path
import os,subprocess,sys
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'logs/performance-fix-20261022';P=ROOT/'windows/build-deps/toolchain/mingw64'
OUT.mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['PATH']=str(P/'bin')+os.pathsep+env.get('PATH','')
def method(text,signature):
 a=text.index(signature);b=text.index('{',a);depth=1;i=b+1
 while depth:depth+=(text[i]=='{')-(text[i]=='}');i+=1
 return text[a:i]
def run(name,args):
 p=subprocess.run(list(map(str,args)),cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=60)
 (OUT/(name+'.log')).write_text(p.stdout+p.stderr,encoding='utf-8');print(name,p.returncode,p.stdout,p.stderr,flush=True)
 if p.returncode:raise RuntimeError(name)
 return p.stdout
def compile_run(name,file,libs=()):
 args=[P/'bin/gcc.exe','-std=gnu11','-O2','-Wall','-Wextra','-I'+str(P/'include'),'-B'+str(P/'lib')+os.sep]
 args+=['-B'+str(d)+os.sep for d in (P/'lib/gcc').glob('*/*') if d.is_dir()]
 exe=OUT/(name+'.exe');args += [file,'-L'+str(P/'lib'),*libs,'-o',exe]
 args=[str(x).replace(str(ROOT)+os.sep,'') for x in args]
 run(name+'-compile',args);return run(name,[exe])

for name,tree in [('windows','windows/build-deps/strongswan-6.1.0'),('android','android-port/engine')]:
 if not (ROOT/tree/'src/libipsec/ipsec_processor.c').exists():continue
 processor=(ROOT/tree/'src/libipsec/ipsec_processor.c').read_text(encoding='utf-8')
 sender=(ROOT/tree/'src/libcharon/network/sender.c').read_text(encoding='utf-8')
 code=r'''
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "../../windows/native/packet_budget.h"
#define METHOD(iface,name,ret,...) static ret name(__VA_ARGS__)
#define CHECK(c,n) do{if(!(c)){fprintf(stderr,"FAIL %s line=%d\n",n,__LINE__);return 1;}puts("PASS: " n);}while(0)
typedef struct {size_t len;} chunk_t;
typedef struct packet_t packet_t;struct packet_t {chunk_t(*get_data)(packet_t*);void(*destroy)(packet_t*);size_t bytes;};
typedef struct esp_packet_t esp_packet_t;struct esp_packet_t {packet_t packet;void(*destroy)(esp_packet_t*);};
typedef struct ip_packet_t ip_packet_t;struct ip_packet_t {chunk_t(*get_encoding)(ip_packet_t*);void(*destroy)(ip_packet_t*);size_t bytes;};
typedef struct mutex_t mutex_t;struct mutex_t {void(*lock)(mutex_t*);void(*unlock)(mutex_t*);CRITICAL_SECTION native;};
static void lock(mutex_t *m){EnterCriticalSection(&m->native);}static void unlock(mutex_t *m){LeaveCriticalSection(&m->native);}
typedef struct list_t list_t;typedef list_t linked_list_t;struct list_t {void(*enqueue)(list_t*,void*);void(*insert_last)(list_t*,void*);void *items[2048];size_t count;};
static void insert(list_t *q,void *p){q->items[q->count++]=p;}
typedef struct cond_t cond_t;struct cond_t {void(*signal)(cond_t*);};static void signal_(cond_t *c){(void)c;}
typedef struct {list_t *inbound_queue,*outbound_queue;mutex_t *queue_lock;forti_packet_budget inbound_budget,outbound_budget;} private_ipsec_processor_t;
typedef struct {list_t *list,*esp_list;mutex_t *mutex;cond_t *got;forti_packet_budget control_budget,esp_budget;} private_sender_t;
static LONG destroyed;
static void free_packet(packet_t *p){InterlockedIncrement(&destroyed);free(p);}static void free_esp(esp_packet_t *p){InterlockedIncrement(&destroyed);free(p);}static void free_ip(ip_packet_t *p){InterlockedIncrement(&destroyed);free(p);}
static chunk_t data(packet_t *p){return (chunk_t){p->bytes};}static chunk_t encoding(ip_packet_t *p){return (chunk_t){p->bytes};}
QUEUE_IN
QUEUE_OUT
ENQUEUE_SENDER
static DWORD WINAPI produce(void *context){private_ipsec_processor_t *p=context;for(int i=0;i<2048;i++){ip_packet_t *ip=calloc(1,sizeof(*ip));ip->get_encoding=encoding;ip->destroy=free_ip;ip->bytes=2048;queue_outbound(p,ip);}return 0;}
int main(void){
 mutex_t m={lock,unlock};InitializeCriticalSection(&m.native);list_t in={insert,insert},out={insert,insert};
 private_ipsec_processor_t p={.inbound_queue=&in,.outbound_queue=&out,.queue_lock=&m};
 HANDLE threads[4];for(int i=0;i<4;i++)threads[i]=CreateThread(NULL,0,produce,&p,0,NULL);WaitForMultipleObjects(4,threads,TRUE,10000);for(int i=0;i<4;i++)CloseHandle(threads[i]);
 CHECK(out.count==512&&p.outbound_budget.packets==512&&p.outbound_budget.bytes==1024*1024,"production outbound enqueue caps four concurrent producers");
 CHECK(destroyed==8192-512,"production overflow destroys every rejected outbound packet");
 for(size_t i=0;i<out.count;i++){ip_packet_t *ip=out.items[i];forti_budget_release(&p.outbound_budget,ip->bytes);ip->destroy(ip);}out.count=0;
 CHECK(!p.outbound_budget.packets&&!p.outbound_budget.bytes&&destroyed==8192,"queue drain releases budget without leaked packets");
 for(int i=0;i<100;i++){esp_packet_t *esp=calloc(1,sizeof(*esp));esp->packet.get_data=data;esp->packet.bytes=65536;esp->destroy=free_esp;queue_inbound(&p,esp);}
 CHECK(in.count==16&&p.inbound_budget.bytes==1024*1024,"production inbound rejects byte overflow before packet count limit");
 for(size_t i=0;i<in.count;i++){esp_packet_t *esp=in.items[i];esp->destroy(esp);}in.count=0;
 list_t control={insert,insert},esp={insert,insert};cond_t cond={signal_};private_sender_t s={.list=&control,.esp_list=&esp,.mutex=&m,.got=&cond};
 for(int i=0;i<1024;i++){packet_t *packet=calloc(1,sizeof(*packet));packet->get_data=data;packet->destroy=free_packet;packet->bytes=2048;enqueue_packet(&s,packet,TRUE);}
 CHECK(esp.count==512&&s.esp_budget.bytes==1024*1024,"production ESP sender remains bounded");
 for(int i=0;i<65;i++){packet_t *packet=calloc(1,sizeof(*packet));packet->get_data=data;packet->destroy=free_packet;packet->bytes=100;enqueue_packet(&s,packet,FALSE);}
 CHECK(control.count==64&&s.control_budget.bytes==6400,"production control reserve accepts IKE despite full ESP queue and stays bounded");
 for(size_t i=0;i<control.count;i++)free_packet(control.items[i]);for(size_t i=0;i<esp.count;i++)free_packet(esp.items[i]);
 DeleteCriticalSection(&m.native);return 0;
}
'''
 code=code.replace('QUEUE_IN',method(processor,'METHOD(ipsec_processor_t, queue_inbound, void,'))
 code=code.replace('QUEUE_OUT',method(processor,'METHOD(ipsec_processor_t, queue_outbound, void,'))
 code=code.replace('ENQUEUE_SENDER',method(sender,'static void enqueue_packet('))
 file=OUT/(name+'-queue-integration.c');file.write_text(code,encoding='utf-8');compile_run(name+'-queue-integration',file)

# Reuse the earlier contention fixture with blocking-lock APIs, against each current source.
template=r'''
#include "SOURCE_FILE"
static DWORD WINAPI contender(void *context){
 hs_session *s=context;uint8_t p[20]={0};
 return send_packet(s,p,0)==0?0:1;
}
static ULONGLONG ticks(FILETIME f){ULARGE_INTEGER n;n.LowPart=f.dwLowDateTime;n.HighPart=f.dwHighDateTime;return n.QuadPart;}
int main(void){
 hs_session *s=hs_create();if(!s)return 1;
 s->data=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);if(s->data==INVALID_SOCKET)return 2;
 hs_socket_buffers(s);DWORD send_timeout=999;int size=sizeof(send_timeout);
 if(getsockopt(s->data,SOL_SOCKET,SO_SNDTIMEO,(char *)&send_timeout,&size))return 3;
 printf("SOCKET send_timeout_ms=%lu receive_buffer_bytes=%d\n",send_timeout,s->receive_buffer);
#ifdef FIXED_LOCKS
 hs_mutex_lock(&s->send_lock);
#else
 atomic_flag_test_and_set(&s->send_lock);
#endif
 uint64_t start=now_ms();HANDLE t=CreateThread(NULL,0,contender,s,0,NULL);if(!t)return 4;
 Sleep(500);
#ifdef FIXED_LOCKS
 hs_mutex_unlock(&s->send_lock);
#else
 atomic_flag_clear(&s->send_lock);
#endif
 if(WaitForSingleObject(t,2000)!=WAIT_OBJECT_0)return 5;
 FILETIME created,exited,kernel,user;if(!GetThreadTimes(t,&created,&exited,&kernel,&user))return 6;
 DWORD code;if(!GetExitCodeThread(t,&code)||code)return 7;
 printf("CONTENTION injected_lock_hold_ms=500 wall_ms=%llu waiting_thread_cpu_ms=%.2f\n",
  (unsigned long long)(now_ms()-start),(ticks(kernel)+ticks(user))/10000.0);
 CloseHandle(t);hs_destroy(s);return 0;
}'''
for name,source in [('windows','hillstone/native/scvpn.c'),('android','android-port/engine/src/frontends/android/app/src/main/jni/hillstone/scvpn.c')]:
 if not (ROOT/source).exists():continue
 lines=template.splitlines();lines[1]='#include "'+os.path.relpath(ROOT/source,OUT).replace('\\','/')+'"'
 file=OUT/(name+'-lock-fixed.c');file.write_text('#define FIXED_LOCKS\n'+'\n'.join(lines),encoding='utf-8')
 output=compile_run(name+'-lock-fixed',file,['-lssl','-lcrypto','-lws2_32'])
 assert 'send_timeout_ms=100' in output
 cpu=float(output.split('waiting_thread_cpu_ms=')[1].split()[0]);assert cpu<100,output
