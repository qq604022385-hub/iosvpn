"""Package Windows 1.4.4 with current send/engine checks and artifact verification."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
WINDOWS = ROOT / "windows"
DIST = WINDOWS / "dist"
VERSION = "1.4.4"
EXE = DIST / f"FortiOneTap-{VERSION}.exe"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

desktop = (WINDOWS / "send-selftests-1.4.4.log").read_text(encoding="utf-8-sig")
send = (ROOT / "logs/send-backpressure-20261022.log").read_text(encoding="utf-8-sig")
pair = (ROOT / "logs/windows-local-pair-20261022.log").read_text(encoding="utf-8-sig")
assert "TOTAL 76 PASS" in desktop and send.count("PASS:") == 17
assert "BIDIRECTIONAL_NATIVE_ESP_ENCRYPT_DECRYPT_OK" in pair
assert "client exit 0" in pair and "server exit 0" in pair
assert "1.4.4".encode("utf-16le") in EXE.read_bytes()
with zipfile.ZipFile(EXE) as payload:
    native = json.loads(payload.read("payload-manifest.json"))
    assert all(hashlib.sha256(payload.read(n)).hexdigest() == h for n, h in native.items())
    assert native["charon-svc.exe"] == digest(WINDOWS / "build-deps/strongswan-6.1.0/src/charon-svc/charon-svc.exe")
assert native["charon-svc.exe"] != json.loads((DIST / "FortiOneTap-1.4.3-BUILD-INFO.json").read_text())["native_payload"]["charon-svc.exe"]

for name in ["README.md", "VERIFICATION.md", "dependencies.lock.json", "payload-manifest.json"]:
    shutil.copyfile(WINDOWS / name, DIST / name)
info = {
    "version": VERSION, "built_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "artifact": EXE.name, "sha256": digest(EXE), "size_bytes": EXE.stat().st_size,
    "architecture": "x64", "desktop_checks": 76, "native_send_checks": 17,
    "native_local_ike_and_bidirectional_esp": "passed", "native_payload": native,
    "send_retry_budget_ms": 100, "persistent_blockage_threshold_ms": 3000,
    "real_gateway_acceptance": False, "existing_user_connection_stopped": False,
}
info_path = DIST / f"FortiOneTap-{VERSION}-BUILD-INFO.json"
info_path.write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")
source = DIST / f"FortiOneTap-{VERSION}-source.zip"
files = [p for p in WINDOWS.iterdir() if p.is_file() and p.suffix in {".cs", ".py", ".ps1", ".sh", ".md", ".json", ".manifest"}]
files += [p for p in (WINDOWS / "native").iterdir() if p.is_file()]
files += [p for p in (WINDOWS / "data").rglob("*") if p.is_file() and p.name != "delegated-apnic-latest.txt"]
files += [p for p in (ROOT / "hillstone/native").iterdir() if p.is_file() and p.suffix in {".c", ".h", ".inc", ".txt", ".ps1", ".json"}]
files += [WINDOWS / "build-deps/strongswan-6.1.0.tar.bz2", ROOT / "COPYING", ROOT / "LICENSE",
          ROOT / "WINDOWS-SEND-1.4.4.md", info_path, Path(__file__).resolve(),
          WINDOWS / "send-selftests-1.4.4.log", ROOT / "logs/send-backpressure-20261022.log",
          ROOT / "logs/windows-local-pair-20261022.log"]
with zipfile.ZipFile(source, "w", zipfile.ZIP_DEFLATED) as bundle:
    for file in sorted(set(files)):
        bundle.write(file, file.relative_to(ROOT).as_posix())
with zipfile.ZipFile(source) as bundle:
    assert bundle.testzip() is None
    assert all(not n.startswith(("/", "\\")) and ".." not in Path(n).parts and not n.endswith(".dpapi") for n in bundle.namelist())
    for name in ["windows/native/send_windows.h", "windows/patch-engine.py", "windows/Engine.cs", "windows/UI.cs", "windows/native/send_windows_test.c"]:
        assert bundle.read(name) == (ROOT / name).read_bytes()
manifest = {"version": VERSION, "platform": "Windows x64", "checks": info,
            "artifacts": [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": digest(p)} for p in [EXE, source]]}
(ROOT / "release-windows-send-1.4.4.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
delivery_path = ROOT / "DELIVERY-MANIFEST.json"
delivery = json.loads(delivery_path.read_text(encoding="utf-8"))
paths = {x["path"] for x in manifest["artifacts"]}
delivery["artifacts"] = [x for x in delivery["artifacts"] if x.get("file") not in paths]
delivery["artifacts"] += [{"file": x["path"], "bytes": x["bytes"], "sha256": x["sha256"], "present": True,
                           "status": "1.4.4 Windows send backpressure repair; host and local ESP checks passed; real gateway pending"}
                          for x in manifest["artifacts"]]
delivery["windows_send_release"] = {"version": VERSION, "manifest": "release-windows-send-1.4.4.json", "updated_at": "2026-10-22"}
delivery_path.write_text(json.dumps(delivery, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(manifest, indent=2))
