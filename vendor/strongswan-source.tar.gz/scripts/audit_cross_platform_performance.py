"""Read-only production audit with synthetic contention and mocked Android APIs.

Does not connect to VPN gateways or change routes. Outputs stay in logs/performance-audit-20261022.
"""
from pathlib import Path
import os, subprocess, json, hashlib
import sys
sys.stdout.reconfigure(encoding='utf-8', errors='replace')

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'logs/performance-audit-20261022'
OUT.mkdir(parents=True, exist_ok=True)
FIXED = Path('C:/Users/7/Desktop/vpn-main')
P = ROOT / 'windows/build-deps/toolchain/mingw64'
J = ROOT / 'android-port/.deps/jdk/jdk-17.0.20.1+1/bin'
env = dict(os.environ)
env['PATH'] = str(P/'bin') + os.pathsep + env.get('PATH', '')
results = {}

def run(name, command, timeout=120):
    p = subprocess.run([str(x) for x in command], cwd=ROOT, env=env, capture_output=True,
                       text=True, encoding='utf-8', errors='replace', timeout=timeout)
    output = p.stdout + p.stderr
    (OUT/(name+'.log')).write_text(output, encoding='utf-8')
    print(name, 'exit=', p.returncode, '\n'+output, flush=True)
    results[name] = {'exit_code':p.returncode, 'output':output}
    if p.returncode: raise RuntimeError(name)
    return output

def method(text, signature):
    start = text.index(signature)
    brace = text.index('{', start)
    depth = 1
    end = brace+1
    while depth:
        depth += (text[end]=='{') - (text[end]=='}')
        end += 1
    return text[start:end]

def native():
    template = r'''
#include "SOURCE_FILE"
static DWORD WINAPI contender(void *context){
 hs_session *s=context;uint8_t p[20]={0};
 return send_packet(s,p,0)==0?0:1;
}
static ULONGLONG ticks(FILETIME f){ULARGE_INTEGER n;n.LowPart=f.dwLowDateTime;n.HighPart=f.dwHighDateTime;return n.QuadPart;}
int main(void){
 hs_session *s=hs_create();if(!s)return 1;
 s->data=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);if(s->data==INVALID_SOCKET)return 2;
 hs_socket_buffers(s);DWORD send_timeout=999;int size=sizeof(send_timeout);
 if(getsockopt(s->data,SOL_SOCKET,SO_SNDTIMEO,(char *)&send_timeout,&size))return 3;
 printf("SOCKET send_timeout_ms=%lu receive_buffer_bytes=%d\n",send_timeout,s->receive_buffer);
#ifdef FIXED_LOCKS
 hs_mutex_lock(&s->send_lock);
#else
 atomic_flag_test_and_set(&s->send_lock);
#endif
 uint64_t start=now_ms();HANDLE t=CreateThread(NULL,0,contender,s,0,NULL);if(!t)return 4;
 Sleep(500);
#ifdef FIXED_LOCKS
 hs_mutex_unlock(&s->send_lock);
#else
 atomic_flag_clear(&s->send_lock);
#endif
 if(WaitForSingleObject(t,2000)!=WAIT_OBJECT_0)return 5;
 FILETIME created,exited,kernel,user;if(!GetThreadTimes(t,&created,&exited,&kernel,&user))return 6;
 DWORD code;if(!GetExitCodeThread(t,&code)||code)return 7;
 printf("CONTENTION injected_lock_hold_ms=500 wall_ms=%llu waiting_thread_cpu_ms=%.2f\n",
  (unsigned long long)(now_ms()-start),(ticks(kernel)+ticks(user))/10000.0);
 CloseHandle(t);hs_destroy(s);return 0;
}
'''
    for name, source, fixed in [
        ('windows-old-lock',ROOT/'hillstone/native/scvpn.c',False),
        ('android-old-lock',ROOT/'android-port/engine/src/frontends/android/app/src/main/jni/hillstone/scvpn.c',False),
        ('ios-fixed-lock-windows-branch',FIXED/'ios/Native/scvpn.c',True),
    ]:
        path=OUT/(name+'.c')
        include = os.path.relpath(source,OUT).replace('\\','/') if source.is_relative_to(ROOT) else source.as_posix()
        path.write_text(template.replace('SOURCE_FILE',include),encoding='utf-8')
        args=[P/'bin/gcc.exe','-std=gnu11','-O2','-I'+str(P/'include'),'-B'+str(P/'lib')+os.sep]
        args += ['-B'+str(d)+os.sep for d in (P/'lib/gcc').glob('*/*') if d.is_dir()]
        if fixed: args+=['-DFIXED_LOCKS']
        exe=OUT/(name+'.exe')
        command=args+[path,'-L'+str(P/'lib'),'-lssl','-lcrypto','-lws2_32','-o',exe]
        command=[str(x).replace(str(ROOT)+os.sep,'') for x in command]
        run(name+'-compile',command)
        run(name,[exe])

def java():
    base=ROOT/'android-port/app/src/main/java/org/strongswan/android'
    service=(base/'logic/CharonVpnService.java').read_text(encoding='utf-8')
    hill=(base/'logic/HillstoneVpnService.java').read_text(encoding='utf-8')
    setter=method(service,'private void setNextProfile(VpnProfile profile)')
    learner=method(hill,'public int learnDomainRoutes(byte[] reply)')
    text=r'''
import org.strongswan.android.onetap.*;
import java.util.*;import java.io.*;import java.util.concurrent.*;
public class AndroidAudit {
 static class VpnProfile {}
 static class Control {
  VpnProfile mNextProfile;boolean mProfileUpdated;
  SETTER
 }
 static class ParcelFileDescriptor {int getFd(){return 42;}void close()throws IOException{}}
 boolean stopping;ParcelFileDescriptor tunnel=new ParcelFileDescriptor();
 DomainRouteCache domainRoutes=new DomainRouteCache(null,"1.1.1.1","115.31.179.179");
 int establishes;
 ParcelFileDescriptor createTunnel(){establishes++;return new ParcelFileDescriptor();}
 LEARNER
 static byte[] answer(int i)throws Exception {
  ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream d=new DataOutputStream(b);
  d.writeShort(i);d.writeShort(0x8180);d.writeShort(1);d.writeShort(1);d.writeInt(0);
  for(String label:"www.baidu.com".split("\\.")){d.writeByte(label.length());d.writeBytes(label);}d.writeByte(0);d.writeShort(1);d.writeShort(1);
  d.writeShort(0xc00c);d.writeShort(1);d.writeShort(1);d.writeInt(60);d.writeShort(4);d.write(new byte[]{9,9,(byte)(i>>8),(byte)i});
  byte[] dns=b.toByteArray(),p=new byte[28+dns.length];p[0]=0x45;p[9]=17;p[20]=0;p[21]=53;
  p[2]=(byte)(p.length>>8);p[3]=(byte)p.length;p[24]=(byte)((p.length-20)>>8);p[25]=(byte)(p.length-20);System.arraycopy(dns,0,p,28,dns.length);return p;
 }
 public static void main(String[] args)throws Exception {
  AndroidAudit a=new AndroidAudit();for(int i=0;i<520;i++)a.learnDomainRoutes(answer(i));
  int before=a.establishes;for(int i=0;i<512;i++)a.learnDomainRoutes(answer(i));
  if(before!=512||a.establishes!=512)throw new AssertionError("unexpected cache behavior");
  System.out.println("ROUTES unique_dns_answers=520 mocked_tun_establish_calls="+before+" duplicate_extra_establish_calls="+(a.establishes-before));
  Control c=new Control();CountDownLatch held=new CountDownLatch(1);
  Thread worker=new Thread(()->{synchronized(c){held.countDown();try{Thread.sleep(1500);}catch(Exception e){throw new RuntimeException(e);}}});
  worker.start();held.await();long start=System.nanoTime();c.setNextProfile(null);long ms=(System.nanoTime()-start)/1000000;worker.join();
  if(ms<1000)throw new AssertionError("did not reproduce monitor wait");
  System.out.println("DISCONNECT production_setNextProfile_blocked_ms="+ms+" injected_native_cleanup_hold_ms=1500");
 }
}
'''.replace('SETTER',setter).replace('LEARNER',learner)
    (OUT/'AndroidAudit.java').write_text(text,encoding='utf-8')
    stub=OUT/'android/util/Log.java';stub.parent.mkdir(parents=True,exist_ok=True)
    stub.write_text('package android.util;public class Log {public static int i(String a,String b){return 0;}}',encoding='utf-8')
    classes=OUT/'java-classes';classes.mkdir(exist_ok=True)
    run('android-audit-compile',[J/'javac.exe','-encoding','UTF-8','-d',classes,OUT/'AndroidAudit.java',stub,base/'onetap/SiteSettings.java',base/'onetap/DomainRouteCache.java'])
    run('android-audit',[J/'java.exe','-cp',classes,'AndroidAudit'])
    cache=ROOT/'android-port/.deps/gradle-cache/caches/modules-2/files-2.1'
    junit=next((cache/'junit/junit/4.13.2').rglob('*.jar'))
    hamcrest=next((cache/'org.hamcrest/hamcrest-core/1.3').rglob('*.jar'))
    cp=os.pathsep.join(map(str,[classes,junit,hamcrest]))
    testbase=ROOT/'android-port/app/src/test/java/org/strongswan/android/onetap'
    run('android-policy-tests-compile',[J/'javac.exe','-encoding','UTF-8','-cp',cp,'-d',classes,
        base/'onetap/RecoveryPolicy.java',base/'onetap/TokenClient.java',
        testbase/'DomainRouteCacheTest.java',testbase/'RecoveryPolicyTest.java',testbase/'TokenClientTest.java'])
    run('android-policy-tests',[J/'java.exe','-cp',cp,'org.junit.runner.JUnitCore',
        'org.strongswan.android.onetap.DomainRouteCacheTest','org.strongswan.android.onetap.RecoveryPolicyTest','org.strongswan.android.onetap.TokenClientTest'])

if __name__=='__main__':
    import sys
    if sys.argv[1:] == ['native']: native()
    elif sys.argv[1:] == ['java']: java()
    else: native();java()
    files=[ROOT/'windows/UI.cs',ROOT/'windows/Engine.cs',ROOT/'hillstone/native/scvpn.c',
       ROOT/'android-port/app/src/main/java/org/strongswan/android/logic/CharonVpnService.java',
       ROOT/'android-port/app/src/main/java/org/strongswan/android/logic/HillstoneVpnService.java',FIXED/'ios/Native/scvpn.c']
    results['source_sha256']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    (OUT/('results-'+(sys.argv[1] if len(sys.argv)>1 else 'all')+'.json')).write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
