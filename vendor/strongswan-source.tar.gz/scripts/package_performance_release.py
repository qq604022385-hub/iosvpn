"""Package only verified 1.4.5 binaries and complete per-platform sources."""
from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,zipfile,sys
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'windows';A=ROOT/'android-port';LOG=ROOT/'logs/performance-fix-20261022'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):return (LOG/name).read_text(encoding='utf-8-sig')
assert 'TOTAL 84 PASS' in read('windows-selftests.log')
assert 'BIDIRECTIONAL_NATIVE_ESP_ENCRYPT_DECRYPT_OK' in read('windows-local-pair.log')
assert 'client exit 0' in read('windows-local-pair.log') and 'server exit 0' in read('windows-local-pair.log')
assert read('windows-send.log').count('PASS:')==17
assert read('windows-pump.log').count('PASS:')==6
assert read('native-performance.log').count('PASS:')==11
for platform in ['windows','android']:
    assert read(platform+'-queue-integration.log').count('PASS:')==6
    assert 'send_timeout_ms=100' in read(platform+'-lock-fixed.log')
    assert float(read(platform+'-lock-fixed.log').split('waiting_thread_cpu_ms=')[1].split()[0])<100
assert 'BUILD SUCCESSFUL' in read('android-build.log')
ainfo=json.loads((A/'dist/BUILD-INFO.json').read_text(encoding='utf-8'))
assert ainfo['version_name']=='1.4.5' and ainfo['version_code']==104
assert ainfo['unit_tests']=={'tests':126,'failures':0,'errors':0}
assert ainfo['lint_errors']==0
exe=W/'dist/FortiOneTap-1.4.5.exe';apk=A/'dist/FortiOneTap-Android-1.4.5.apk'
assert b'1\x00.\x004\x00.\x005\x00' in exe.read_bytes()
assert sha(apk)==ainfo['sha256']
with zipfile.ZipFile(exe) as z:
    payload=json.loads(z.read('payload-manifest.json'))
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in payload.items())
    assert payload['charon-svc.exe']==sha(W/'build-deps/strongswan-6.1.0/src/charon-svc/charon-svc.exe')
    assert payload['scvpn.dll']==sha(ROOT/'hillstone/native/scvpn.dll')
old=json.loads((W/'dist/FortiOneTap-1.4.4-BUILD-INFO.json').read_text(encoding='utf-8'))
assert payload['charon-svc.exe']!=old['native_payload']['charon-svc.exe']
assert payload['scvpn.dll']!=old['native_payload']['scvpn.dll']
oldapk=A/'dist/FortiOneTap-Android-1.4.3.apk'
with zipfile.ZipFile(apk) as new,zipfile.ZipFile(oldapk) as oldzip:
    changed=[]
    for abi in ['arm64-v8a','armeabi-v7a','x86_64']:
        for lib in ['libipsec.so','libcharon.so','libscvpn.so','libandroidbridge.so']:
            name='lib/'+abi+'/'+lib
            assert new.read(name)!=oldzip.read(name),name
            changed.append(name)
info={'version':'1.4.5','built_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'architecture':'Windows x64','artifact':exe.name,'sha256':sha(exe),'bytes':exe.stat().st_size,
 'desktop_checks':84,'native_send_checks':17,'hillstone_pump_checks':6,'performance_policy_checks':11,
 'queue_integration_checks_per_platform':6,'native_payload':payload,'real_gateway_acceptance':False,
 'existing_user_connection_stopped':False}
for name in ['FortiOneTap-1.4.5-BUILD-INFO.json','BUILD-INFO.json']:
    (W/'dist'/name).write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
for name in ['README.md','VERIFICATION.md','payload-manifest.json']:
    shutil.copyfile(W/name,W/'dist'/name)
(A/'dist/VERIFICATION.md').write_text((ROOT/'PERFORMANCE-FIX-1.4.5.md').read_text(encoding='utf-8'),encoding='utf-8')
subprocess.run([sys.executable,A/'package-source.py'],cwd=ROOT,check=True)
wsource=W/'dist/FortiOneTap-1.4.5-source.zip'
files=[p for p in W.iterdir() if p.is_file() and p.suffix in {'.cs','.py','.ps1','.sh','.md','.json','.manifest'}]
files += [p for p in (W/'native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt','.json'}]
files += [p for p in (W/'data').rglob('*') if p.is_file() and p.name!='delegated-apnic-latest.txt']
files += [p for p in (ROOT/'hillstone/native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt','.ps1','.json'}]
files += [ROOT/'COPYING',ROOT/'LICENSE',ROOT/'PERFORMANCE-FIX-1.4.5.md',W/'build-deps/strongswan-6.1.0.tar.bz2',
 ROOT/'scripts/patch_performance_engines.py',ROOT/'scripts/test_performance_fix.py',Path(__file__),
 A/'engine/src/frontends/android/app/src/main/jni/hillstone/dns_route_batch.h']
files += [p for p in LOG.glob('*.log') if 'build' not in p.name and '-compile' not in p.name]
with zipfile.ZipFile(wsource,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):z.write(p,p.relative_to(ROOT).as_posix())
asource=A/'dist/FortiOneTap-Android-1.4.5-source.zip'
for archive in [wsource,asource]:
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert not any(n.endswith('.dpapi') or '.signing/' in n or '..' in Path(n).parts for n in z.namelist())
with zipfile.ZipFile(wsource) as z:
    for n in ['windows/BufferedLog.cs','windows/UI.cs','windows/Engine.cs','windows/native/packet_budget.h','scripts/patch_performance_engines.py','hillstone/native/scvpn.c']:
        assert z.read(n)==(ROOT/n).read_bytes()
with zipfile.ZipFile(asource) as z:
    for n in ['app/src/main/java/org/strongswan/android/onetap/ConnectionCommands.java',
              'app/src/main/java/org/strongswan/android/onetap/DomainRouteUpdates.java',
              'engine/src/libipsec/ipsec_processor.c','engine/src/libcharon/network/sender.c',
              'engine/src/frontends/android/app/src/main/jni/hillstone/bridge.c']:
        assert z.read('android-port/'+n)==(A/n).read_bytes()
sources=[W/'UI.cs',W/'Engine.cs',W/'BufferedLog.cs',W/'PerformanceTests.cs',ROOT/'hillstone/native/scvpn.c',
 ROOT/'hillstone/native/split_dns.h',ROOT/'windows/native/packet_budget.h',ROOT/'scripts/patch_performance_engines.py']
sources += list((A/'app/src/main/java/org/strongswan/android/onetap').glob('*Commands.java'))
sources += [A/'app/src/main/java/org/strongswan/android/onetap/DomainRouteUpdates.java',
 A/'app/src/main/java/org/strongswan/android/logic/CharonVpnService.java',A/'app/src/main/java/org/strongswan/android/logic/HillstoneVpnService.java',
 A/'engine/src/libipsec/ipsec_processor.c',A/'engine/src/libcharon/network/sender.c',
 A/'engine/src/frontends/android/app/src/main/jni/hillstone/scvpn.c',A/'engine/src/frontends/android/app/src/main/jni/hillstone/bridge.c',
 A/'engine/src/frontends/android/app/src/main/jni/libandroidbridge/backend/android_service.c']
manifest={'version':'1.4.5','date':'2026-10-22','windows':info,
 'android':{'version_code':104,'jvm_tests':ainfo['unit_tests'],'lint_errors':0,'lint_warnings':ainfo['lint_warnings'],
 'signature_sha256':ainfo['certificate_sha256'],'verified_native_libraries_changed_from_1_4_3':changed,
 'phone_endurance_acceptance':False,'real_gateway_acceptance':False},
 'artifacts':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in [exe,apk,wsource,asource]],
 'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in sources}}
(ROOT/'release-performance-1.4.5.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
delivery_path=ROOT/'DELIVERY-MANIFEST.json';delivery=json.loads(delivery_path.read_text(encoding='utf-8'))
paths={x['path'] for x in manifest['artifacts']};delivery['artifacts']=[x for x in delivery['artifacts'] if x.get('file') not in paths]
delivery['artifacts'] += [{'file':x['path'],'bytes':x['bytes'],'sha256':x['sha256'],'present':True,
 'status':'1.4.5 performance repair; build and host checks passed; real gateway/device acceptance pending'} for x in manifest['artifacts']]
delivery['performance_release']={'version':'1.4.5','manifest':'release-performance-1.4.5.json','updated_at':'2026-10-22'}
delivery_path.write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
