"""Package the automatic-OTP release without borrowing historical gateway acceptance."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = "1.4.2"
WINDOWS = ROOT / "windows"
DIST = WINDOWS / "dist"
EXE = DIST / f"FortiOneTap-{VERSION}.exe"

def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

checks = (WINDOWS / f"token-selftests-{VERSION}.log").read_text(encoding="utf-8-sig")
assert "TOTAL 69 PASS" in checks
assert checks.count("PASS token:") == 19
assert "http://47.103.139.56:9000/api/key".encode("utf-16le") in EXE.read_bytes()
for name in ["README.md", "VERIFICATION.md", "dependencies.lock.json", "payload-manifest.json"]:
    shutil.copyfile(WINDOWS / name, DIST / name)

info = {
    "version": VERSION,
    "built_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "artifact": EXE.name,
    "sha256": digest(EXE),
    "size_bytes": EXE.stat().st_size,
    "architecture": "x64",
    "selftests": 69,
    "token_checks": 19,
    "native_payload": json.loads((WINDOWS / "payload-manifest.json").read_text()),
    "token": {"endpoint": "http://47.103.139.56:9000/api/key", "format": "six ASCII digits",
              "cache": False, "persistent": False, "manual_fallback": True},
    "live_endpoint": {"http_status": 502, "valid_token_received": False},
    "real_gateway_acceptance": "Not performed for this release.",
}
(DIST / f"FortiOneTap-{VERSION}-BUILD-INFO.json").write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")
archive = DIST / f"FortiOneTap-{VERSION}-source.zip"
allowed = {".cs", ".c", ".h", ".py", ".ps1", ".sh", ".json", ".md", ".manifest"}
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
    files = [p for p in WINDOWS.iterdir() if p.is_file() and (p.suffix in allowed or p.name == ".gitignore")]
    files += [p for p in (WINDOWS / "native").iterdir() if p.is_file()]
    files += [p for p in (WINDOWS / "data").rglob("*") if p.is_file() and p.name != "delegated-apnic-latest.txt"]
    native_ext = {".c", ".h", ".inc", ".txt", ".ps1", ".json"}
    files += [p for p in (ROOT / "hillstone/native").iterdir() if p.is_file() and p.suffix in native_ext]
    files += [WINDOWS / "build-deps/strongswan-6.1.0.tar.bz2", ROOT / "COPYING", ROOT / "LICENSE",
              ROOT / "AUTO-TOKEN-1.4.2.md", Path(__file__).resolve(),
              WINDOWS / f"token-selftests-{VERSION}.log",
              DIST / f"FortiOneTap-{VERSION}-BUILD-INFO.json"]
    for file in sorted(set(files)):
        bundle.write(file, file.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert bundle.read("windows/TokenClient.cs") == (WINDOWS / "TokenClient.cs").read_bytes()
    assert all(not n.startswith(("/", "\\")) and ".." not in Path(n).parts for n in bundle.namelist())

artifacts = [EXE, archive, ROOT / f"android-port/dist/FortiOneTap-Android-{VERSION}.apk",
             ROOT / f"android-port/dist/FortiOneTap-Android-{VERSION}-source.zip",
             ROOT / f"ios/artifacts/FortiOneTap-iOS-{VERSION}-source.zip"]
expected_sources = {
    artifacts[3]: "android-port/app/src/main/java/org/strongswan/android/onetap/TokenClient.java",
    artifacts[4]: "ios/App/TokenClient.swift",
}
for file, member in expected_sources.items():
    with zipfile.ZipFile(file) as bundle:
        assert bundle.testzip() is None
        assert bundle.read(member) == (ROOT / member).read_bytes()
        assert not any(".signing/" in n or n.endswith("password.dpapi") for n in bundle.namelist())
with zipfile.ZipFile(artifacts[2]) as apk:
    assert any(b"http://47.103.139.56:9000/api/key" in apk.read(n) for n in apk.namelist() if n.endswith(".dex"))

manifest = {"version": VERSION, "live_endpoint_http_status": 502,
            "real_gateway_acceptance": False, "ios_ipa_built": False,
            "artifacts": [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size,
                           "sha256": digest(p)} for p in artifacts]}
(ROOT / f"release-token-{VERSION}.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
delivery_path = ROOT / "DELIVERY-MANIFEST.json"
delivery = json.loads(delivery_path.read_text(encoding="utf-8"))
new_paths = {item["path"] for item in manifest["artifacts"]}
delivery["artifacts"] = [item for item in delivery["artifacts"] if item.get("file") not in new_paths]
delivery["artifacts"] += [{"file": item["path"], "bytes": item["bytes"], "sha256": item["sha256"],
                           "present": True, "status": "1.4.2 automatic OTP; live endpoint returned 502; real gateway acceptance pending"}
                          for item in manifest["artifacts"]]
delivery["automatic_token_release"] = {"version": VERSION, "updated_at": "2026-10-20",
                                       "manifest": f"release-token-{VERSION}.json",
                                       "ios_delivery": "source only; no IPA built"}
delivery_path.write_text(json.dumps(delivery, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(manifest, indent=2))
