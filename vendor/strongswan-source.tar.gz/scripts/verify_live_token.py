"""Probe the configured token service without displaying or persisting its token."""
import datetime
import json
from pathlib import Path
import re
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
ENDPOINT = "http://47.103.139.56:9000/api/key"


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def main():
    opener = urllib.request.build_opener(NoRedirect)
    request = urllib.request.Request(ENDPOINT, headers={
        "Accept": "text/plain", "Cache-Control": "no-cache, no-store"})
    result = {"checked_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "endpoint": ENDPOINT, "http_status": None, "valid_token_received": False,
              "token_logged_or_persisted": False}
    start = time.monotonic()
    try:
        with opener.open(request, timeout=8) as response:
            result["http_status"] = response.status
            body = response.read(65)
            result["response_bytes"] = len(body)
            result["valid_token_received"] = (response.status == 200 and len(body) <= 64
                and re.fullmatch(rb"[0-9]{6}", body.strip(b" \t\r\n")) is not None)
            del body
    except urllib.error.HTTPError as exc:
        result["http_status"] = exc.code
        result["error_type"] = "HTTPError"
    except Exception as exc:
        result["error_type"] = type(exc).__name__
    result["elapsed_ms"] = round((time.monotonic() - start) * 1000)
    output = ROOT / "logs" / "token-preflight-20261021.json"
    output.parent.mkdir(exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if result["valid_token_received"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
