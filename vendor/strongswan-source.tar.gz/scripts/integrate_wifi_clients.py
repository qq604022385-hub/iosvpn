"""Wire network selection and standard NAT-T fallback into mobile clients."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
A=ROOT/'android-port/app/src/main/java/org/strongswan/android'
def edit(p,old,new):
    s=p.read_text(encoding='utf-8')
    if old not in s:raise RuntimeError(f'Missing anchor in {p}: {old[:70]}')
    p.write_text(s.replace(old,new),encoding='utf-8')

p=A/'logic/HillstoneVpnService.java'
edit(p,'private Network physicalNetwork;', 'private volatile Network physicalNetwork;')
edit(p,'private void state(String text){status=text;', '''private static final java.util.ArrayDeque<String> history=new java.util.ArrayDeque<>();
 public static String diagnostics(){synchronized(history){return String.join("\\n",history);}}
 private void state(String text){synchronized(history){while(history.size()>=40)history.removeFirst();history.addLast(text);}status=text;''')
edit(p,'  synchronized(gate){if(stopping)return null;session=HillstoneNative.create();}', '''  Network physical=OuterNetwork.select(cm);physicalNetwork=physical;
  final Network initial=physical;
  callback=new ConnectivityManager.NetworkCallback(){@Override public void onLost(Network network){if(initial.equals(network)){state("外层网络变化，正在重连…");synchronized(gate){if(session!=0)HillstoneNative.cancel(session);}}}};
  cm.registerNetworkCallback(new NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build(),callback);
  synchronized(gate){if(stopping)return null;session=HillstoneNative.create();}''')
edit(p,'  Network physical=cm.getActiveNetwork();if(physical!=null){NetworkCapabilities capabilities=cm.getNetworkCapabilities(physical);if(capabilities!=null&&capabilities.hasTransport(NetworkCapabilities.TRANSPORT_VPN))throw new Exception("请先断开其他 VPN。");}physicalNetwork=physical;','')
edit(p,'  if(physical!=null){final Network initial=physical;callback=new ConnectivityManager.NetworkCallback(){@Override public void onLost(Network network){if(initial.equals(network)){state("本地网络变化，正在自动重连…");synchronized(gate){if(session!=0)HillstoneNative.cancel(session);}}}};cm.registerNetworkCallback(new NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build(),callback);}','')
edit(p,' private ParcelFileDescriptor createTunnel(){', ''' // JNI calls this before connecting both TLS and UDP sockets.
 public boolean protectAndBind(int socket){
  if(stopping||!protect(socket))return false;
  Network network=physicalNetwork;if(network==null)return false;
  try{OuterNetwork.bind(network,socket);return !stopping;}catch(java.io.IOException e){return false;}
 }
 private ParcelFileDescriptor createTunnel(){''')
edit(A/'ui/OneTapActivity.java','message(HillstoneVpnService.status)','message(HillstoneVpnService.diagnostics())')
edit(ROOT/'android-port/engine/src/frontends/android/app/src/main/jni/hillstone/bridge.c','"protect","(I)Z"','"protectAndBind","(I)Z"')

p=A/'logic/VpnStateService.java'
edit(p,'    private boolean mKeepConnected;', '''    private final org.strongswan.android.onetap.FortiPortPolicy mFortiPorts=new org.strongswan.android.onetap.FortiPortPolicy();
    private boolean mKeepConnected;''')
edit(p,'            mTimeoutProvider.reset();','            mTimeoutProvider.reset();\n            mFortiPorts.reset();')
edit(p,'        intent.putExtras(profileInfo);', '''        profileInfo.putInt("forti_remote_port",mFortiPorts.port());
        intent.putExtras(profileInfo);''')
a=p.read_text(encoding='utf-8').index('            for(android.net.Network network:cm.getAllNetworks()){')
s=p.read_text(encoding='utf-8');b=s.index('        });mTokenRequest=request;',a)
s=s[:a]+'''            return (java.net.HttpURLConnection)org.strongswan.android.onetap.OuterNetwork.select(cm).openConnection(endpoint);
'''+s[b:];p.write_text(s,encoding='utf-8')
edit(p,'                    VpnStateService.this.mError = error;', '''                    if(error==ErrorState.UNREACHABLE && mProfile!=null && mProfile.getVpnType()==VpnType.IKEV1_XAUTH_PSK)mFortiPorts.unreachable();
                    VpnStateService.this.mError = error;''')
p=A/'logic/CharonVpnService.java'
edit(p,'profile.setAppendToken(s.appendToken);', '''profile.setAppendToken(s.appendToken);
                                int remotePort=bundle.getInt("forti_remote_port",500);
                                profile.setPort(remotePort==4500?4500:500);''')
p=ROOT/'android-port/engine/src/frontends/android/app/src/main/jni/libandroidbridge/backend/android_service.c'
s=p.read_text(encoding='utf-8');anchor='\tike.no_certreq = '
edit(p,anchor,'''\t/* Initial IKE on NAT-T requires a non-500 source and Non-ESP marker. */
\tif (ikev1_xauth_psk && ike.remote_port == IKEV2_NATT_PORT)
\t{ ike.local_port = charon->socket->get_port(charon->socket, TRUE); }
'''+anchor)
print('Android outer-network binding, retained diagnostics and bounded Forti NAT-T retry integrated')
