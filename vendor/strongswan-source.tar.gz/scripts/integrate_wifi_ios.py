"""Preserve the existing Forti ABI and add an explicit standard NAT-T entry."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];I=ROOT/'ios'
def edit(p,old,new):
    s=p.read_text(encoding='utf-8')
    if old not in s:raise RuntimeError(f'Missing anchor: {p}: {old[:60]}')
    p.write_text(s.replace(old,new),encoding='utf-8')
p=I/'Native/FortiBridge.h'
edit(p,'void fot_stop(void);', '''// Remote port is restricted to standard IKE (500) or NAT-T (4500).
int fot_start_on_port(const char *runtime, const char *gateway, const char *username,
              const char *password, const char *psk, const char *local_id,
              const char *token, int append_token, void *context,
              fot_event_cb event, fot_packet_cb packet, uint16_t remote_port);
void fot_stop(void);''')
p=I/'Native/FortiBridge.c'
edit(p,'static atomic_bool stopping;', 'static atomic_bool stopping, peer_seen;')
edit(p,'static listener_t listener = { .child_updown = child_event, .ike_updown = ike_event };', '''static bool peer_message(listener_t *listener, ike_sa_t *ike, message_t *message, bool incoming, bool plain) {
    if (incoming && plain) atomic_store(&peer_seen, TRUE);
    return TRUE;
}
static listener_t listener = { .child_updown = child_event, .ike_updown = ike_event, .message = peer_message };''')
edit(p,'int fot_start(const char *runtime,', 'int fot_start_on_port(const char *runtime,')
edit(p,'fot_event_cb event, fot_packet_cb packet) {\n    fot_stop(); atomic_store(&stopping, FALSE);', '''fot_event_cb event, fot_packet_cb packet, uint16_t remote_port) {
    bool awaiting_peer = FALSE;
    fot_stop(); atomic_store(&stopping, FALSE); atomic_store(&peer_seen, FALSE);''')
edit(p,'!token || strlen(gateway)', '!token || (remote_port != 500 && remote_port != 4500) || strlen(gateway)')
edit(p,'    kv(r, "fragmentation", "yes");', '''    kv(r, "fragmentation", "yes");
    if (remote_port == 4500) {
        char local_port[16];
        snprintf(local_port, sizeof(local_port), "%u", charon->socket->get_port(charon->socket, TRUE));
        kv(r, "local_port", local_port); kv(r, "remote_port", "4500");
        notify("log", "Wi-Fi 兼容重试：直接使用标准 UDP 4500 NAT-T 入口。");
    }''')
edit(p,'    if (!submit(r)) goto fail;\n    // A later reauthentication', '    awaiting_peer = TRUE;\n    if (!submit(r)) goto fail;\n    awaiting_peer = FALSE;\n    // A later reauthentication')
edit(p,'    notify("error", failure);', '    notify(awaiting_peer && !atomic_load(&peer_seen) ? "unreachable" : "error", failure);')
with p.open('a',encoding='utf-8') as f:f.write('''
int fot_start(const char *runtime, const char *gateway, const char *username,
              const char *password, const char *psk, const char *local_id,
              const char *token, int append_token, void *context,
              fot_event_cb event, fot_packet_cb packet) {
    return fot_start_on_port(runtime,gateway,username,password,psk,local_id,
                             token,append_token,context,event,packet,500);
}
''')
p=I/'Tunnel/PacketTunnelProvider.swift'
edit(p,'    private var fortiAuthenticationRejected = false', '    private var fortiAuthenticationRejected = false\n    private var fortiPortPolicy = FortiPortPolicy()')
edit(p,'self.fortiStopping = false; self.reconnecting = false; self.reconnectAttempt = 0;', 'self.fortiStopping = false; self.fortiPortPolicy = FortiPortPolicy(); self.reconnecting = false; self.reconnectAttempt = 0;')
edit(p,'        let generation = self.generation, settings = profile', '        let generation = self.generation, settings = profile, remotePort = fortiPortPolicy.port')
edit(p,'let result = fot_start(', 'let result = fot_start_on_port(')
edit(p,'Unmanaged.passUnretained(self).toOpaque(), onEngineEvent, onEnginePacket)', 'Unmanaged.passUnretained(self).toOpaque(), onEngineEvent, onEnginePacket, remotePort)')
edit(p,'            case "phase": self.startPhase', '''            case "unreachable":
                if !self.fortiStopping {
                    if !self.fortiAuthenticationRejected, self.fortiPortPolicy.nextAfterNoResponse() {
                        self.recoverForti("UDP 500 协商无有效应答，读取新令牌后尝试 UDP 4500。")
                    } else { self.fail(detail, retryable: self.hasConnected) }
                }
            case "phase": self.startPhase''')
print('iOS no-response-only NAT-T retry integrated; original fot_start ABI preserved')
