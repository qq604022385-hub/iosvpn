from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
source=(ROOT/'scripts/native/wifi_udp_test.c').read_text(encoding='utf-8')
for dest,include in [('ios/NativeTests/wifi_udp_test.c','../Native/scvpn.c'),
 ('android-port/native-tests/wifi-udp-test.c','../engine/src/frontends/android/app/src/main/jni/hillstone/scvpn.c')]:
    (ROOT/dest).write_text(source.replace('#include HS_ENGINE_SOURCE',f'#include "{include}"'),encoding='utf-8')
