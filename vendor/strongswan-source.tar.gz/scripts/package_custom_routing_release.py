"""Package Windows 1.4.7 with checked executable, rule policy, and source."""
from pathlib import Path
import datetime, hashlib, json, shutil, zipfile, sys

sys.stdout.reconfigure(encoding='utf8', errors='replace')
ROOT=Path(__file__).resolve().parents[1]
W=ROOT/'windows'
EXE=W/'dist/FortiOneTap-1.4.7.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))

assert 'TOTAL 136 PASS' in (ROOT/'logs/custom-routing-selftests-20261022.log').read_text(encoding='utf-8-sig')
tun=read(W/'validation-custom-tun-20261022/result.json')
egress=read(W/'validation-custom-egress-20261022/result.json')
assert tun['passed']==23 and egress['passed']==2
assert egress['tested_executable_sha256']==sha(EXE)
for name,digest in tun['policy_sha256'].items():
    assert sha(W/'validation-custom-routing-20261022-final/routing-rules'/name)==digest
with zipfile.ZipFile(EXE) as z:
    payload=json.loads(z.read('payload-manifest.json'))
    assert all(hashlib.sha256(z.read(n)).hexdigest()==digest for n,digest in payload.items())
    assert payload==read(ROOT/'release-desktop-routing-1.4.6.json')['windows']['native_payload'], 'Native payload must remain unchanged from 1.4.6'
info={'version':'1.4.7','platform':'Windows x64','date':'2026-10-22',
      'built_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'artifact':EXE.name,'sha256':sha(EXE),'bytes':EXE.stat().st_size,
      'desktop_checks':136,'isolated_tun_checks':23,'real_https_rule_egress_checks':2,
      'native_payload':payload,'native_payload_unchanged_from':'1.4.6',
      'current_vpn_restarted':False,'final_exe_gateway_reauthentication_tested':False,
      'hillstone_online_acceptance':False,'android_ios_updated':False}
for name in ('FortiOneTap-1.4.7-BUILD-INFO.json','BUILD-INFO.json'):
    (W/'dist'/name).write_text(json.dumps(info,indent=2)+'\n',encoding='utf8')
for source,target in ((ROOT/'CUSTOM-ROUTING-1.4.7.md',W/'dist/CUSTOM-ROUTING-1.4.7.md'),
                      (W/'README.md',W/'dist/README.md'),
                      (W/'data/routing-rules-example.xml',W/'dist/routing-rules-example.xml')):
    shutil.copyfile(source,target)
files=[p for p in W.iterdir() if p.is_file() and p.suffix in {'.cs','.py','.ps1','.sh','.md','.json','.manifest'}]
files += [p for p in (W/'native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt'}]
files += [p for p in (W/'data').rglob('*') if p.is_file() and p.name!='delegated-apnic-latest.txt']
files += [p for p in (ROOT/'hillstone/native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt','.ps1'}]
files += [ROOT/'COPYING',ROOT/'LICENSE',ROOT/'CUSTOM-ROUTING-1.4.7.md',ROOT/'DESKTOP-APP-ROUTING-1.4.6.md',Path(__file__),
          ROOT/'scripts/patch_performance_engines.py', W/'build-deps/strongswan-6.1.0.tar.bz2',W/'build-deps/sing-box/source.json',
          ROOT/'android-port/engine/src/frontends/android/app/src/main/jni/hillstone/dns_route_batch.h',
          ROOT/'logs/custom-routing-selftests-20261022.log',ROOT/'logs/custom-routing-ui-1.4.7.png',
          W/'validation-custom-tun-20261022/result.json',W/'validation-custom-egress-20261022/result.json']
for name in ('custom-config.json','custom-only-config.json','ip-only-config.json'):
    files.append(W/'validation-custom-routing-20261022-final/routing-rules'/name)
archive=W/'dist/FortiOneTap-1.4.7-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(n.endswith('.dpapi') or n.endswith('/.env') or '..' in Path(n).parts for n in z.namelist())
    for name in ('windows/RoutingRules.cs','windows/RoutingRulesUI.cs','windows/DesktopAppRouter.cs','windows/UI.cs','windows/build.ps1'):
        assert z.read(name)==(ROOT/name).read_bytes()
manifest={'version':'1.4.7','windows':info,'artifacts':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in (EXE,archive)],
          'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in files if p.suffix in {'.cs','.c','.h','.py','.ps1'}}}
(ROOT/'release-custom-routing-1.4.7.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
delivery_file=ROOT/'DELIVERY-MANIFEST.json';delivery=read(delivery_file)
paths={a['path'] for a in manifest['artifacts']}
delivery['artifacts']=[a for a in delivery['artifacts'] if a.get('file') not in paths]
delivery['artifacts'] += [dict(file=a['path'],bytes=a['bytes'],sha256=a['sha256'],present=True,status='Windows 1.4.7 editable routing; 136 desktop, 23 isolated TUN, 2 real HTTPS egress checks; final full gateway session pending') for a in manifest['artifacts']]
delivery['custom_routing_release']={'version':'1.4.7','manifest':'release-custom-routing-1.4.7.json','updated_at':'2026-10-22'}
delivery_file.write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'exe':str(EXE),'source':str(archive),'checks':{'desktop':136,'tun':23,'real_https_egress':2},'sha256':sha(EXE)},ensure_ascii=False,indent=2))
