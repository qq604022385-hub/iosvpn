"""Verify the final 1.4.8 artifacts and record their actual source/payload hashes."""
from pathlib import Path
import hashlib,json,zipfile,datetime
ROOT=Path(__file__).resolve().parents[1];A=ROOT/'android-port';I=ROOT/'ios';W=ROOT/'windows'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
apk=A/'dist/FortiOneTap-Android-1.4.8.apk';exe=W/'dist/FortiOneTap-1.4.8.exe'
asource=A/'dist/FortiOneTap-Android-1.4.8-source.zip';isource=I/'artifacts/FortiOneTap-iOS-1.4.8-source.zip'
ainfo=json.loads((A/'dist/BUILD-INFO.json').read_text(encoding='utf-8'))
assert ainfo['version_name']=='1.4.8' and ainfo['version_code']==108 and ainfo['sha256']==sha(apk)
assert ainfo['unit_tests']=={'tests':131,'failures':0,'errors':0} and ainfo['lint_errors']==0
assert 'BUILD SUCCESSFUL' in (A/'build-assembleRelease-testDebugUnitTest-lintDebug.log').read_text(encoding='utf-8')
marker=b'data_heartbeat_timeout udp_port=%u local_port=%u paths=%u probes=%u raw=%u invalid=%u auth_bad=%u os=%d'
with zipfile.ZipFile(apk) as z,zipfile.ZipFile(A/'dist/FortiOneTap-Android-1.4.5.apk') as old:
    for abi in ['arm64-v8a','armeabi-v7a','x86_64']:
        for lib in ['libscvpn.so','libandroidbridge.so']:
            path=f'lib/{abi}/{lib}';assert z.read(path)!=old.read(path),path
        assert marker in z.read(f'lib/{abi}/libscvpn.so')
        assert b'protectAndBind' in z.read(f'lib/{abi}/libscvpn.so')
    assert b'forti_remote_port' in b''.join(z.read(n) for n in z.namelist() if n.endswith('.dex'))
with zipfile.ZipFile(exe) as z:
    payload=json.loads(z.read('payload-manifest.json'))
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in payload.items())
    assert payload['scvpn.dll']==sha(ROOT/'hillstone/native/scvpn.dll')
    assert marker in z.read('scvpn.dll')
for platform in ['windows','android','ios']:
    log=(ROOT/f'logs/wifi-client-1.4.8/{platform}-udp-tests.log').read_text(encoding='utf-8')
    assert log.count('PASS:')==5
assert 'exit=0' in (ROOT/'logs/wifi-client-1.4.8/ios-forti-portable-syntax.log').read_text(encoding='utf-8')

with zipfile.ZipFile(asource) as z:
    for file in ['app/src/main/java/org/strongswan/android/onetap/OuterNetwork.java',
                 'app/src/main/java/org/strongswan/android/onetap/FortiPortPolicy.java',
                 'app/src/main/java/org/strongswan/android/logic/HillstoneVpnService.java',
                 'engine/src/frontends/android/app/src/main/jni/hillstone/scvpn.c',
                 'engine/src/frontends/android/app/src/main/jni/hillstone/udp_connect.h',
                 'native-tests/wifi-udp-test.c','native-tests/test_split_native.py']:
        assert z.read('android-port/'+file)==(A/file).read_bytes(),file
with zipfile.ZipFile(isource) as z:
    for file in ['Native/scvpn.c','Native/udp_connect.h','Native/FortiBridge.c','Native/FortiBridge.h',
                 'Core/FortiPortPolicy.swift','Tunnel/PacketTunnelProvider.swift','project.yml',
                 'NativeTests/wifi_udp_test.c','scripts/test_native.py']:
        assert z.read('ios/'+file)==(I/file).read_bytes(),file

wsource=W/'dist/FortiOneTap-1.4.8-source.zip'
files=[p for p in W.iterdir() if p.is_file() and p.suffix in {'.cs','.py','.ps1','.sh','.md','.json','.manifest'}]
files += [p for p in (W/'native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt','.json'}]
files += [p for p in (W/'data').rglob('*') if p.is_file() and p.name!='delegated-apnic-latest.txt']
files += [p for p in (ROOT/'hillstone/native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt','.ps1','.json'}]
files += [ROOT/'COPYING',ROOT/'LICENSE',ROOT/'WIFI-CLIENT-1.4.8.md',W/'build-deps/strongswan-6.1.0.tar.bz2']
files += [ROOT/'scripts'/f for f in ['patch_performance_engines.py','test_performance_fix.py','patch_wifi_clients.py','test_wifi_clients.py','sync_wifi_tests.py','package_wifi_release.py','native/wifi_udp_test.c']]
files += [A/'engine/src/frontends/android/app/src/main/jni/hillstone/dns_route_batch.h']
files += list((ROOT/'logs/wifi-client-1.4.8').glob('*.log'))
with zipfile.ZipFile(wsource,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):z.write(p,p.relative_to(ROOT).as_posix())
for archive in [wsource,asource,isource]:
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert not any('.signing/' in n or n.endswith('.dpapi') or '..' in Path(n).parts for n in z.namelist())
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
info={'version':'1.4.8','built_at':now,'artifact':exe.name,'sha256':sha(exe),
      'bytes':exe.stat().st_size,'native_payload':payload,'windows_managed_regression_checks':136,
      'hillstone_udp_fault_injection_checks':5,'real_wifi_acceptance':False,
      'existing_user_connection_stopped':False,'forti_natt_fallback_added':False}
for name in ['FortiOneTap-1.4.8-BUILD-INFO.json','BUILD-INFO.json']:
    (W/'dist'/name).write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
artifacts=[exe,apk,asource,isource,wsource]
manifest={'version':'1.4.8','built_at':now,
 'artifacts':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in artifacts],
 'checks':{'udp_fault_injection':15,'android_jvm':131,'android_native':31,'android_dns':8,
           'android_lint_errors':0,'windows_managed':136,'windows_pump':6,'ios_host_tools':16,
           'ios_native_host_passed':True,'ios_forti_android_sysroot_syntax_passed':True,
           'apple_sdk_build':False,'swift_tests_executed':False,'real_gateway':False,'real_wifi':False},
 'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in [
      ROOT/'hillstone/native/scvpn.c',ROOT/'hillstone/native/udp_connect.h',
      I/'Native/scvpn.c',I/'Native/FortiBridge.c',I/'Tunnel/PacketTunnelProvider.swift',
      A/'engine/src/frontends/android/app/src/main/jni/hillstone/scvpn.c',
      A/'app/src/main/java/org/strongswan/android/logic/HillstoneVpnService.java']}}
(ROOT/'release-wifi-client-1.4.8.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
path=ROOT/'DELIVERY-MANIFEST.json';delivery=json.loads(path.read_text(encoding='utf-8'))
paths={x['path'] for x in manifest['artifacts']}
delivery['artifacts']=[x for x in delivery['artifacts'] if x.get('file') not in paths]
delivery['artifacts'] += [{'file':x['path'],'bytes':x['bytes'],'sha256':x['sha256'],'present':True,
                        'status':'1.4.8 client compatibility build; real Wi-Fi acceptance pending'} for x in manifest['artifacts']]
delivery['wifi_client_release']={'version':'1.4.8','manifest':'release-wifi-client-1.4.8.json','real_wifi_acceptance':False}
path.write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'verified_artifacts':manifest['artifacts'],'checks':manifest['checks']},ensure_ascii=False,indent=2))
