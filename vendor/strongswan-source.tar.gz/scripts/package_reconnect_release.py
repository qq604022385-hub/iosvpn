"""Package verified 1.4.3 deliverables; do not borrow historical gateway acceptance."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

ROOT = Path(__file__).resolve().parents[1]
VERSION = "1.4.3"
WINDOWS = ROOT / "windows"
DIST = WINDOWS / "dist"
EXE = DIST / f"FortiOneTap-{VERSION}.exe"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


checks = (WINDOWS / f"token-selftests-{VERSION}.log").read_text(encoding="utf-8-sig")
assert "TOTAL 73 PASS" in checks and checks.count("PASS token:") == 19
assert "manual disconnect cancels pending automatic reconnect" in checks
live = json.loads((ROOT / "logs/token-preflight-20261021.json").read_text(encoding="utf-8"))
assert live["http_status"] == 200 and live["valid_token_received"]
for name in ["windows", "android"]:
    assert (ROOT / f"logs/{name}-live-token-20261021.log").read_text(encoding="utf-8-sig").count("PASS:") == 2
android = json.loads((ROOT / "android-port/dist/BUILD-INFO.json").read_text(encoding="utf-8"))
assert android["version_name"] == VERSION and android["unit_tests"] == {"tests": 121, "failures": 0, "errors": 0}
assert android["lint_errors"] == 0 and android["native_split_checks"] == 31
assert "Ran 16 tests" in (ROOT / "logs/ios-host-20261021.log").read_text(encoding="utf-8-sig")
assert "PASS: host C compilation" in (ROOT / "logs/ios-native-20261021.log").read_text(encoding="utf-8-sig")
for name in ["README.md", "VERIFICATION.md", "dependencies.lock.json", "payload-manifest.json"]:
    shutil.copyfile(WINDOWS / name, DIST / name)
info = {
    "version": VERSION, "built_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "artifact": EXE.name, "sha256": digest(EXE), "size_bytes": EXE.stat().st_size,
    "architecture": "x64", "selftests": 73, "token_checks": 19,
    "native_payload": json.loads((WINDOWS / "payload-manifest.json").read_text()),
    "live_endpoint": live, "live_production_client_requests": 2,
    "automatic_reconnect": {"providers": ["forti", "hillstone"], "max_delay_seconds": 60,
                            "fresh_forti_token_per_login": True, "manual_disconnect_cancels": True},
    "real_gateway_acceptance": False,
}
info_path = DIST / f"FortiOneTap-{VERSION}-BUILD-INFO.json"
info_path.write_text(json.dumps(info, indent=2) + "\n", encoding="utf-8")
archive = DIST / f"FortiOneTap-{VERSION}-source.zip"
allowed = {".cs", ".c", ".h", ".py", ".ps1", ".sh", ".json", ".md", ".manifest"}
with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as bundle:
    files = [p for p in WINDOWS.iterdir() if p.is_file() and (p.suffix in allowed or p.name == ".gitignore")]
    files += [p for p in (WINDOWS / "native").iterdir() if p.is_file()]
    files += [p for p in (WINDOWS / "data").rglob("*") if p.is_file() and p.name != "delegated-apnic-latest.txt"]
    files += [p for p in (ROOT / "hillstone/native").iterdir()
              if p.is_file() and p.suffix in {".c", ".h", ".inc", ".txt", ".ps1", ".json"}]
    files += [WINDOWS / "build-deps/strongswan-6.1.0.tar.bz2", ROOT / "COPYING", ROOT / "LICENSE",
              ROOT / "RECONNECT-1.4.3.md", Path(__file__).resolve(),
              WINDOWS / f"token-selftests-{VERSION}.log", info_path]
    for file in sorted(set(files)):
        bundle.write(file, file.relative_to(ROOT).as_posix())

artifacts = [EXE, archive, ROOT / f"android-port/dist/FortiOneTap-Android-{VERSION}.apk",
             ROOT / f"android-port/dist/FortiOneTap-Android-{VERSION}-source.zip",
             ROOT / f"ios/artifacts/FortiOneTap-iOS-{VERSION}-source.zip"]
source_members = {
    archive: ["windows/UI.cs", "windows/RecoveryPolicy.cs", "windows/Engine.cs", "windows/Hillstone.cs"],
    artifacts[3]: ["android-port/app/src/main/java/org/strongswan/android/logic/VpnStateService.java",
                   "android-port/app/src/main/java/org/strongswan/android/logic/HillstoneVpnService.java",
                   "android-port/app/src/main/java/org/strongswan/android/onetap/TokenClient.java"],
    artifacts[4]: ["ios/Tunnel/PacketTunnelProvider.swift", "ios/Shared/TokenClient.swift",
                   "ios/App/VPNController.swift", "ios/project.yml"],
}
for file, members in source_members.items():
    with zipfile.ZipFile(file) as bundle:
        assert bundle.testzip() is None
        for member in members:
            assert bundle.read(member) == (ROOT / member).read_bytes(), member
        assert not any(".signing/" in n or n.endswith(".dpapi") for n in bundle.namelist())
        assert all(not n.startswith(("/", "\\")) and ".." not in Path(n).parts for n in bundle.namelist())
with zipfile.ZipFile(artifacts[2]) as apk:
    assert any(b"http://47.103.139.56:9000/api/key" in apk.read(n) for n in apk.namelist() if n.endswith(".dex"))
    assert "source" not in apk.namelist()
manifest = {
    "version": VERSION, "created_at": info["built_at"], "live_endpoint": live,
    "real_gateway_acceptance": False, "real_device_reconnect_acceptance": False,
    "ios_ipa_built": False, "ios_delivery": "source only, as requested by user",
    "checks": {"windows_selftests": 73, "windows_token_checks": 19,
               "android_jvm": android["unit_tests"], "android_lint_errors": 0,
               "android_lint_warnings": android["lint_warnings"], "android_native_split": 31,
               "android_native_dns": 8, "ios_host": 16, "ios_native_host": "passed",
               "ios_processor_regression": "passed", "ios_apple_sdk": "not run"},
    "artifacts": [{"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size,
                   "sha256": digest(p)} for p in artifacts],
}
(ROOT / f"release-reconnect-{VERSION}.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
delivery_path = ROOT / "DELIVERY-MANIFEST.json"
delivery = json.loads(delivery_path.read_text(encoding="utf-8"))
paths = {item["path"] for item in manifest["artifacts"]}
delivery["artifacts"] = [x for x in delivery["artifacts"] if x.get("file") not in paths]
delivery["artifacts"] += [{"file": x["path"], "bytes": x["bytes"], "sha256": x["sha256"],
                           "present": True, "status": "1.4.3 reconnect; host/package checks passed; gateway/device acceptance pending"}
                          for x in manifest["artifacts"]]
delivery["automatic_reconnect_release"] = {"version": VERSION, "updated_at": "2026-10-21",
                                          "manifest": f"release-reconnect-{VERSION}.json", "ios_delivery": "source only"}
delivery_path.write_text(json.dumps(delivery, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(manifest, indent=2))
