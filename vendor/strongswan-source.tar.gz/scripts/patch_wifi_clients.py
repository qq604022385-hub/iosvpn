"""Apply the shared initial UDP recovery implementation to existing engines."""
from pathlib import Path
import re, shutil
ROOT=Path(__file__).resolve().parents[1]
TREES=[ROOT/'hillstone/native', ROOT/'ios/Native', ROOT/'android-port/engine/src/frontends/android/app/src/main/jni/hillstone']

def patch(base):
    p=base/'scvpn.c';s=p.read_text(encoding='utf-8')
    if '#include "udp_connect.h"' in s:return
    s=s.replace('char error_detail[96]', 'char error_detail[256]')
    s=s.replace('uint64_t last_sent_heartbeat;', 'uint64_t last_sent_heartbeat,last_receive_tick;')
    s=s.replace('uint16_t data_port;', '''uint16_t data_port;
 unsigned udp_local_port,udp_paths,udp_probes,udp_raw,udp_invalid,udp_auth_bad;
 int udp_last_os;''')
    a=s.index('static int receive_packet(');b=s.index('static void make_heartbeat(',a)
    block=s[a:b]
    block=block.replace('return -1;}if(n<36', 's->udp_last_os=hs_socket_error();return -1;}s->udp_raw++;if(n<36')
    # Count rejected packets before authenticated inner IPv4 delivery. Keep
    # existing SPI/HMAC/replay/IPv4 validation and replay-window semantics.
    block=block.replace('return 0;', '{s->udp_invalid++;return 0;}')
    block=block.replace('if(!readable(s->data,ms)){s->udp_invalid++;return 0;}', 'if(!readable(s->data,ms))return 0;')
    block=block.replace('if(n<0&&WSAGetLastError()==WSAEWOULDBLOCK){s->udp_invalid++;return 0;}', 'if(n<0&&WSAGetLastError()==WSAEWOULDBLOCK)return 0;')
    block=block.replace('if(!HMAC(EVP_sha1(),s->rx_auth,20,raw,(size_t)n-12,mac,&mac_size)||mac_size!=20||CRYPTO_memcmp(mac,raw+n-12,12)){s->udp_invalid++;return 0;}',
      'if(!HMAC(EVP_sha1(),s->rx_auth,20,raw,(size_t)n-12,mac,&mac_size)||mac_size!=20||CRYPTO_memcmp(mac,raw+n-12,12)){s->udp_auth_bad++;s->udp_invalid++;return 0;}')
    s=s[:a]+block+s[b:]
    s=s.replace('HS_API hs_session *hs_create(void){', '#include "udp_connect.h"\nHS_API hs_session *hs_create(void){')
    a=s.index(' s->data=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);',s.index('HS_API int hs_connect('))
    b=s.index(' done:OPENSSL_cleanse(seed',a)
    s=s[:a]+' ok=hs_udp_establish(s,&remote,&local,protect,context);\n'+s[b:]
    s=s.replace('if(s->data!=INVALID_HS_SOCKET)shutdown(s->data,2);',
      'hs_mutex_lock(&s->send_lock);if(s->data!=INVALID_HS_SOCKET)shutdown(s->data,2);hs_mutex_unlock(&s->send_lock);')
    # Existing mutex engines need their locks destroyed. The iOS engine uses
    # atomic flags and provides matching shared-header adapters below.
    if 'hs_mutex_destroy(&s->send_lock)' not in s:
        s=s.replace(' OPENSSL_cleanse(s,sizeof(*s));free(s);', ' hs_mutex_destroy(&s->send_lock);hs_mutex_destroy(&s->dns_lock);\n OPENSSL_cleanse(s,sizeof(*s));free(s);')
    if 'atomic_flag send_lock' in s:
        s=s.replace('#define HS_MAX 65536', '''#define HS_MAX 65536
static void hs_mutex_lock(atomic_flag *lock){while(atomic_flag_test_and_set(lock)){
#ifdef _WIN32
 Sleep(1);
#else
 usleep(1000);
#endif
}}
static void hs_mutex_unlock(atomic_flag *lock){atomic_flag_clear(lock);}
static void hs_mutex_destroy(atomic_flag *lock){(void)lock;}''')
    p.write_text(s,encoding='utf-8')

if __name__=='__main__':
    for base in TREES:
        patch(base)
        if base!=TREES[0]:shutil.copyfile(TREES[0]/'udp_connect.h',base/'udp_connect.h')
    print('Shared bounded UDP recovery applied to Windows, Android and iOS sources')
