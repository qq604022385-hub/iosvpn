"""Package only the Windows 1.4.6 application-routing release and evidence."""
from pathlib import Path
import datetime, hashlib, json, shutil, zipfile, sys
sys.stdout.reconfigure(encoding='utf-8',errors='replace')
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'windows'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def result(folder):return json.loads((W/folder/'result.json').read_text(encoding='utf8'))
assert 'TOTAL 99 PASS' in (ROOT/'logs/app-routing-selftests-20261022.log').read_text(encoding='utf-8-sig')
guard=result('validation-app-guard-20261022');tun=result('validation-app-tun-20261022');egress=result('validation-app-egress-20261022')
assert guard['passed']==10 and tun['passed']==15
assert len(egress['checks'])==3 and all(c['outbound_source_is_vpn_vip'] for c in egress['checks'])
exe=W/'dist/FortiOneTap-1.4.6.exe'
with zipfile.ZipFile(exe) as z:
    payload=json.loads(z.read('payload-manifest.json'))
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in payload.items())
    assert payload['scvpn.dll']==sha(ROOT/'hillstone/native/scvpn.dll')
    assert payload['sing-box.exe']==sha(W/'build-deps/sing-box/sing-box-1.14.3-windows-amd64/sing-box.exe')
    assert payload['charon-svc.exe']==sha(W/'build-deps/strongswan-6.1.0/src/charon-svc/charon-svc.exe')
info={'version':'1.4.6','platform':'Windows x64','date':'2026-10-22','built_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'artifact':exe.name,'sha256':sha(exe),'bytes':exe.stat().st_size,'desktop_checks':99,'wfp_checks':10,'tun_checks':15,
      'existing_forti_vpn_source_binding_checks':3,'public_https_200':sum(c['http_200'] for c in egress['checks']),
      'native_payload':payload,'current_vpn_restarted':False,'final_exe_gateway_reauthentication_tested':False,
      'real_codex_claude_long_session_acceptance':False,'hillstone_online_acceptance':False}
for name in ('FortiOneTap-1.4.6-BUILD-INFO.json','BUILD-INFO.json'):(W/'dist'/name).write_text(json.dumps(info,indent=2)+'\n',encoding='utf8')
for name in ('README.md','VERIFICATION.md','payload-manifest.json'):shutil.copyfile(W/name,W/'dist'/name)
shutil.copyfile(ROOT/'DESKTOP-APP-ROUTING-1.4.6.md',W/'dist/DESKTOP-APP-ROUTING-1.4.6.md')
files=[p for p in W.iterdir() if p.is_file() and p.suffix in {'.cs','.py','.ps1','.sh','.md','.json','.manifest'}]
files += [p for p in (W/'native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt'}]
files += [p for p in (W/'data').rglob('*') if p.is_file() and p.name!='delegated-apnic-latest.txt']
files += [p for p in (ROOT/'hillstone/native').iterdir() if p.is_file() and p.suffix in {'.c','.h','.inc','.txt','.ps1'}]
files += [ROOT/'COPYING',ROOT/'LICENSE',ROOT/'DESKTOP-APP-ROUTING-1.4.6.md',Path(__file__),ROOT/'scripts/patch_performance_engines.py',
          W/'build-deps/strongswan-6.1.0.tar.bz2',W/'build-deps/sing-box/source.json',
          ROOT/'android-port/engine/src/frontends/android/app/src/main/jni/hillstone/dns_route_batch.h',
          ROOT/'logs/app-routing-selftests-20261022.log']
for folder in ('validation-app-guard-20261022','validation-app-tun-20261022','validation-app-egress-20261022'):files.append(W/folder/'result.json')
archive=W/'dist/FortiOneTap-1.4.6-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(set(files)):z.write(p,p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert not any(n.endswith('.dpapi') or n.endswith('/.env') or '..' in Path(n).parts for n in z.namelist())
    for n in ('windows/UI.cs','windows/DesktopAppRouter.cs','windows/native/app_guard.c','windows/build.ps1'):
        assert z.read(n)==(ROOT/n).read_bytes()
manifest={'version':'1.4.6','windows':info,'artifacts':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in (exe,archive)],
          'source_sha256':{p.relative_to(ROOT).as_posix():sha(p) for p in files if p.suffix in {'.cs','.c','.h','.py','.ps1'}}}
(ROOT/'release-desktop-routing-1.4.6.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
delivery_path=ROOT/'DELIVERY-MANIFEST.json';delivery=json.loads(delivery_path.read_text(encoding='utf8'))
paths={a['path'] for a in manifest['artifacts']};delivery['artifacts']=[a for a in delivery['artifacts'] if a.get('file') not in paths]
delivery['artifacts'] += [dict(file=a['path'],bytes=a['bytes'],sha256=a['sha256'],present=True,status='Windows 1.4.6 app routing; local WFP/TUN and existing VPN binding checked; final app sessions pending') for a in manifest['artifacts']]
delivery['desktop_routing_release']={'version':'1.4.6','manifest':'release-desktop-routing-1.4.6.json','updated_at':'2026-10-22'}
delivery_path.write_text(json.dumps(delivery,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print(json.dumps({'exe':str(exe),'source':str(archive),'sha256':info['sha256'],'checks':{'desktop':99,'wfp':10,'tun':15,'existing_vpn_binding':3}},ensure_ascii=False,indent=2))
