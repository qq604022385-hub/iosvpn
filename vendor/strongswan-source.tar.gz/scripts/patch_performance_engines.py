"""Idempotent bounded-packet patches; never alter the shared blocking_queue API."""
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]

def patch_tree(root):
    p=root/'src/libipsec/ipsec_processor.c';s=p.read_text(encoding='utf-8')
    if 'FortiOneTap bounded packet budgets' not in s:
        s=s.replace('#include <threading/rwlock.h>','#include <threading/rwlock.h>\n#include <threading/mutex.h>\n#include <utils/packet_budget.h>')
        s=s.replace('blocking_queue_t *outbound_queue;', 'blocking_queue_t *outbound_queue;\n\t/* FortiOneTap bounded packet budgets: guarded independently of callbacks. */\n\tmutex_t *queue_lock;\n\tforti_packet_budget inbound_budget, outbound_budget;')
        for direction,typ,size in [('inbound','esp_packet_t','packet->packet.get_data(&packet->packet).len'),('outbound','ip_packet_t','packet->get_encoding(packet).len')]:
            line=f'packet = ({typ}*)this->{direction}_queue->dequeue(this->{direction}_queue);'
            s=s.replace(line,line+f'\n\tthis->queue_lock->lock(this->queue_lock);\n\tforti_budget_release(&this->{direction}_budget, {size});\n\tthis->queue_lock->unlock(this->queue_lock);')
            line=f'\tthis->{direction}_queue->enqueue(this->{direction}_queue, packet);'
            s=s.replace(line,f'''\tthis->queue_lock->lock(this->queue_lock);
\tif (!forti_budget_reserve(&this->{direction}_budget, {size}, 512, 1024*1024))
\t{{
\t\tthis->queue_lock->unlock(this->queue_lock);
\t\tpacket->destroy(packet);
\t\treturn;
\t}}
{line}
\tthis->queue_lock->unlock(this->queue_lock);''')
        s=s.replace('this->lock->destroy(this->lock);','this->lock->destroy(this->lock);\n\tthis->queue_lock->destroy(this->queue_lock);')
        s=s.replace('.inbound_queue = blocking_queue_create(),','.queue_lock = mutex_create(MUTEX_TYPE_DEFAULT),\n\t\t.inbound_queue = blocking_queue_create(),')
        p.write_text(s,encoding='utf-8')
    p=root/'src/libcharon/network/sender.c';s=p.read_text(encoding='utf-8')
    if 'FortiOneTap bounded ESP/control queues' not in s:
        s=s.replace('#include <threading/mutex.h>','#include <threading/mutex.h>\n#include <utils/packet_budget.h>')
        s=s.replace('linked_list_t *list;', '''linked_list_t *list;
\t/* FortiOneTap bounded ESP/control queues. IKE and keepalives have priority. */
\tlinked_list_t *esp_list;
\tforti_packet_budget control_budget, esp_budget;''')
        a=s.index('METHOD(sender_t, send_no_marker, void,');b=s.index('METHOD(sender_t, send_, void,',a)
        s=s[:a]+'''static void enqueue_packet(private_sender_t *this, packet_t *packet, bool esp)
{
\tsize_t bytes = packet->get_data(packet).len;
\tforti_packet_budget *budget = esp ? &this->esp_budget : &this->control_budget;
\tthis->mutex->lock(this->mutex);
\tif (!forti_budget_reserve(budget, bytes, esp ? 512 : 64, esp ? 1024*1024 : 256*1024))
\t{
\t\tthis->mutex->unlock(this->mutex);
\t\tpacket->destroy(packet);
\t\treturn;
\t}
\tlinked_list_t *list = esp ? this->esp_list : this->list;
\tlist->insert_last(list, packet);
\tthis->got->signal(this->got);
\tthis->mutex->unlock(this->mutex);
}
METHOD(sender_t, send_no_marker, void,
\tprivate_sender_t *this, packet_t *packet)
{
\t/* This entry carries ESP and one-byte NAT keepalives, not send_() IKE. */
\tenqueue_packet(this, packet, packet->get_data(packet).len > 1);
}

'''+s[b:]
        s=s.replace('send_no_marker(this, packet);','enqueue_packet(this, packet, FALSE);')
        s=s.replace('while (this->list->get_count(this->list) == 0)','while (!this->list->get_count(this->list) && !this->esp_list->get_count(this->esp_list))')
        s=s.replace('this->list->remove_first(this->list, (void**)&packet);','''bool control = this->list->get_count(this->list) != 0;
\tlinked_list_t *list = control ? this->list : this->esp_list;
\tlist->remove_first(list, (void**)&packet);
\tforti_budget_release(control ? &this->control_budget : &this->esp_budget, packet->get_data(packet).len);''')
        s=s.replace('while (this->list->get_count(this->list))','while (this->list->get_count(this->list) || this->esp_list->get_count(this->esp_list))')
        s=s.replace('this->list->destroy_offset(this->list, offsetof(packet_t, destroy));','this->list->destroy_offset(this->list, offsetof(packet_t, destroy));\n\tthis->esp_list->destroy_offset(this->esp_list, offsetof(packet_t, destroy));')
        s=s.replace('.list = linked_list_create(),','.list = linked_list_create(),\n\t\t.esp_list = linked_list_create(),')
        p.write_text(s,encoding='utf-8')
    shutil.copyfile(ROOT/'windows/native/packet_budget.h',root/'src/libstrongswan/utils/packet_budget.h')

if __name__=='__main__':
    patch_tree(ROOT/'windows/build-deps/strongswan-6.1.0')
    patch_tree(ROOT/'android-port/engine')
    print('Applied bounded libipsec and priority sender budgets to both engine trees')
