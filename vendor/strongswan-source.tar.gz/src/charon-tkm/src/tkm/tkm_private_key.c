/*
 * Copyright (C) 2026 Tobias Brunner
 * Copyright (C) 2012-2013 Reto Buerki
 * Copyright (C) 2012-2013 Adrian-Ken Rueegsegger
 *
 * Copyright (C) secunet Security Networks AG
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.  See <http://www.fsf.org/copyleft/gpl.txt>.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 */

#include <library.h>
#include <utils/debug.h>
#include <tkm/constants.h>
#include <tkm/client.h>

#include "tkm.h"
#include "tkm_utils.h"
#include "tkm_types.h"
#include "tkm_keymat.h"
#include "tkm_private_key.h"

typedef struct private_tkm_private_key_t private_tkm_private_key_t;

/**
 * Private data of a tkm_private_key_t object.
 */
struct private_tkm_private_key_t {

	/**
	 * Public interface for this signer.
	 */
	tkm_private_key_t public;

	/**
	 * Key ID.
	 */
	identification_t *id;

	/**
	 * Key type.
	 */
	key_type_t key_type;

	/**
	 * Reference count.
	 */
	refcount_t ref;

};

METHOD(private_key_t, get_type, key_type_t,
	private_tkm_private_key_t *this)
{
	return this->key_type;
}

METHOD(private_key_t, sign, bool,
	private_tkm_private_key_t *this, signature_scheme_t scheme, void *params,
	chunk_t data, chunk_t *signature)
{
	signature_type sig;
	blob_id_type msg_id;
	sign_info_t *sign;
	siga_id_type siga_id;
	chunk_t init;
	bool success = FALSE;

	if (data.ptr == NULL)
	{
		DBG1(DBG_LIB, "unable to get signature information");
		return FALSE;
	}
	sign = (sign_info_t*)data.ptr;
	init = chunk_skip(data, sizeof(sign_info_t));

	siga_id = siga_from_signature_scheme(scheme);
	if (!siga_id)
	{
		DBG1(DBG_LIB, "unable to map signature scheme %N to SigA context id",
			 signature_scheme_names, scheme);
		return FALSE;
	}

	msg_id = tkm->idmgr->acquire_id(tkm->idmgr, TKM_CTX_BLOB);
	if (!msg_id)
	{
		DBG1(DBG_LIB, "unable to acquire blob context id for init message");
		return FALSE;
	}

	if (chunk_to_blob(msg_id, &init) &&
		ike_isa_sign(sign->isa_id, 1, msg_id, siga_id, &sig) == TKM_OK)
	{
		sequence_to_chunk(sig.data, sig.size, signature);
		success = TRUE;
	}
	else
	{
		DBG1(DBG_LIB, "signature operation failed");
	}

	tkm->idmgr->release_id(tkm->idmgr, TKM_CTX_BLOB, msg_id);
	return success;
}

METHOD(private_key_t, decrypt, bool,
	private_tkm_private_key_t *this, encryption_scheme_t scheme,
	void *params, chunk_t crypto, chunk_t *plain)
{
	return FALSE;
}

METHOD(private_key_t, get_keysize, int,
	private_tkm_private_key_t *this)
{
	return 0;
}

METHOD(private_key_t, get_public_key, public_key_t*,
	private_tkm_private_key_t *this)
{
	return NULL;
}

METHOD(private_key_t, get_encoding, bool,
	private_tkm_private_key_t *this, cred_encoding_type_t type,
	chunk_t *encoding)
{
	return FALSE;
}

METHOD(private_key_t, get_fingerprint, bool,
	private_tkm_private_key_t *this, cred_encoding_type_t type, chunk_t *fp)
{
	*fp = this->id->get_encoding(this->id);
	return TRUE;
}

METHOD(private_key_t, get_ref, private_key_t*,
	private_tkm_private_key_t *this)
{
	ref_get(&this->ref);
	return &this->public.key;
}

METHOD(private_key_t, destroy, void,
	private_tkm_private_key_t *this)
{
	if (ref_put(&this->ref))
	{
		this->id->destroy(this->id);
		free(this);
	}
}

/**
 * See header.
 */
tkm_private_key_t *tkm_private_key_init(identification_t * const id)
{
	private_tkm_private_key_t *this;
	certificate_t *cert;
	public_key_t *pubkey;

	INIT(this,
		.public = {
			.key = {
				.get_type = _get_type,
				.sign = _sign,
				.decrypt = _decrypt,
				.get_keysize = _get_keysize,
				.get_public_key = _get_public_key,
				.equals = private_key_equals,
				.belongs_to = private_key_belongs_to,
				.get_fingerprint = _get_fingerprint,
				.has_fingerprint = private_key_has_fingerprint,
				.get_encoding = _get_encoding,
				.get_ref = _get_ref,
				.destroy = _destroy,
			},
		},
		.ref = 1,
		.id = id->clone(id),
	);

	/* get key type from associated public key */
	cert = lib->credmgr->get_cert(lib->credmgr, CERT_ANY, KEY_ANY, id, FALSE);
	if (!cert)
	{
		destroy(this);
		return NULL;
	}

	pubkey = cert->get_public_key(cert);
	if (!pubkey)
	{
		cert->destroy(cert);
		destroy(this);
		return NULL;
	}
	this->key_type = pubkey->get_type(pubkey);
	pubkey->destroy(pubkey);
	cert->destroy(cert);

	return &this->public;
}
